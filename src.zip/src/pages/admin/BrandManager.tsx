import React, { useState } from 'react';
import { useGallery } from '@/contexts/GalleryContext';
import { Brand } from '@/types/gallery';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Search, Edit, Trash2, Globe, Shield, Image as ImageIcon } from 'lucide-react';
import { cn, getOptimizedImageUrl } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { toast } from 'sonner';

const BrandManager = () => {
  const { brands, addBrand, updateBrand, deleteBrand } = useGallery();
  const [selectedBrand, setSelectedBrand] = useState<Brand | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name) {
      toast.error('Brand identity name required');
      return;
    }

    const data = new FormData();
    data.append('name', formData.name);
    if (formData.description) data.append('description', formData.description);
    if (logoFile) {
      data.append('logo', logoFile);
    }

    try {
      if (selectedBrand) {
        await updateBrand(selectedBrand.id, data);
        toast.success('Brand partnership refined');
      } else {
        await addBrand(data);
        toast.success('New brand partner established');
      }
      setIsDialogOpen(false);
      setSelectedBrand(null);
      setLogoFile(null);
      setFormData({ name: '', description: '' });
    } catch (error) {
      toast.error('Failed to save brand partnership');
    }
  };

  const handleEdit = (brand: Brand) => {
    setSelectedBrand(brand);
    setFormData({
      name: brand.name,
      description: brand.description || '',
    });
    setIsDialogOpen(true);
  };

  return (
    <div className="space-y-12">
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-10">
        <div className="max-w-3xl">
          <div className="flex items-center gap-4 mb-6">
            <div className="w-8 h-[1px] bg-accent" />
            <span className="text-[10px] font-black uppercase tracking-[0.4em] text-accent">Partners & Solutions</span>
          </div>
          <h2 className="text-4xl md:text-5xl lg:text-7xl font-serif font-light text-foreground leading-none tracking-tighter">
            Company <span className="italic text-foreground/30 text-5xl md:text-6xl lg:text-7xl">Manager.</span>
          </h2>
          <p className="mt-10 text-[10px] sm:text-xs text-foreground/40 uppercase tracking-[0.3em] font-sans font-bold leading-loose">
            Managing company partnerships and material sources.
          </p>
        </div>

        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button 
              onClick={() => {
                setSelectedBrand(null);
                setFormData({ name: '', description: '' });
                setLogoFile(null);
              }}
              className="h-16 px-10 rounded-none bg-accent hover:bg-foreground text-background font-black uppercase tracking-[0.3em] text-[10px] transition-all duration-700 shadow-[0_0_30px_rgba(229,142,88,0.2)]"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add New Company Profile
            </Button>
          </DialogTrigger>
          <DialogContent className="glass-sepia border-foreground/10 text-foreground rounded-none max-w-2xl shadow-[0_0_100px_rgba(0,0,0,0.8)]">
            <DialogHeader>
              <DialogTitle className="text-2xl font-serif font-light tracking-tighter lowercase italic">
                {selectedBrand ? 'Refine Profile' : 'Register New Company'}
              </DialogTitle>
              <div className="w-12 h-px bg-accent/30 mx-auto mt-4" />
            </DialogHeader>
            
            <form onSubmit={handleSubmit} className="space-y-8 mt-8">
              <div className="space-y-3">
                <Label className="text-[9px] font-black uppercase tracking-widest text-foreground/40">Company Name</Label>
                <Input 
                  value={formData.name} 
                  onChange={e => setFormData({...formData, name: e.target.value})}
                  className="bg-foreground/5 border-foreground/10 rounded-none h-12 focus:border-accent transition-colors"
                  placeholder="e.g. Italian Heritage..."
                  required
                />
              </div>

              <div className="space-y-3">
                <Label className="text-[9px] font-black uppercase tracking-widest text-foreground/40">Company Logo</Label>
                <div className="flex gap-4">
                  <Input 
                    type="file"
                    accept="image/*"
                    onChange={e => setLogoFile(e.target.files?.[0] || null)}
                    className="bg-foreground/5 border-foreground/10 rounded-none h-12 focus:border-accent transition-colors pt-2"
                  />
                  <div className="w-12 h-12 bg-foreground/5 border border-foreground/10 flex items-center justify-center shrink-0">
                    <ImageIcon className="w-5 h-5 text-accent/40" />
                  </div>
                </div>
                {selectedBrand?.logo && !logoFile && (
                  <p className="text-[8px] text-foreground/20 italic">Current logo: {selectedBrand.logo.split('/').pop()}</p>
                )}
              </div>

              <div className="space-y-3">
                <Label className="text-[9px] font-black uppercase tracking-widest text-foreground/40">Company Vision / Description</Label>
                <textarea 
                  value={formData.description} 
                  onChange={e => setFormData({...formData, description: e.target.value})}
                  className="w-full bg-foreground/5 border border-foreground/10 rounded-none p-4 h-32 focus:border-accent transition-colors outline-none text-sm"
                  placeholder="Define the brand's position in the premium market..."
                />
              </div>

              <Button type="submit" className="w-full bg-accent text-background hover:bg-foreground rounded-none h-14 text-[10px] font-black uppercase tracking-widest transition-colors shadow-[0_0_30px_rgba(229,142,88,0.2)]">
                {selectedBrand ? 'Commit Refinement' : 'Finalize Partnership'}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10 mt-20">
        <AnimatePresence mode="popLayout">
          {brands.map((brand, idx) => (
            <motion.div
              key={brand.id}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="group relative bg-card border border-foreground/5 p-10 hover:border-accent/40 transition-all duration-1000 hover:bg-foreground/[0.02] shadow-[0_20px_50px_rgba(0,0,0,0.5)]"
            >
              <div className="flex justify-between items-start mb-8">
                <div className="w-16 h-16 bg-foreground/5 flex items-center justify-center border border-foreground/5 group-hover:border-accent/30 transition-colors overflow-hidden">
                    {brand.logo ? (
                      <img 
                        src={getOptimizedImageUrl(brand.logo, 100, 100)} 
                        alt={brand.name} 
                        className="w-full h-full object-cover grayscale opacity-50 group-hover:opacity-100 group-hover:grayscale-0 transition-all duration-700" 
                      />
                    ) : (
                     <Globe className="w-6 h-6 text-foreground/20 group-hover:text-accent transition-colors" />
                   )}
                </div>
                <div className="flex gap-4 opacity-0 group-hover:opacity-100 transition-opacity">
                   <button onClick={() => handleEdit(brand)} className="text-foreground/40 hover:text-foreground transition-colors"><Edit size={14} /></button>
                   <button onClick={() => deleteBrand(brand.id)} className="text-red-500/40 hover:text-red-500 transition-colors"><Trash2 size={14} /></button>
                </div>
              </div>
              
              <h3 className="text-2xl font-serif font-light text-foreground mb-4 tracking-tight group-hover:text-accent transition-colors italic">{brand.name}</h3>
              <p className="text-[10px] text-foreground/40 uppercase tracking-widest leading-relaxed mb-8 line-clamp-3">{brand.description}</p>
              
              <div className="flex items-center gap-3 pt-6 border-t border-foreground/5">
                 <Shield className="w-3 h-3 text-accent/40" />
                 <span className="text-[8px] font-black uppercase tracking-widest text-foreground/20">Verified Source</span>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {brands.length === 0 && (
          <div className="col-span-full py-40 text-center border border-dashed border-foreground/5">
             <Globe className="w-8 h-8 text-foreground/10 mx-auto mb-4" />
             <p className="text-[10px] font-black uppercase tracking-widest text-foreground/10 italic">Zero Companies Registered</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default BrandManager;
